import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:elderly_people/widget/PredefinedWidgets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../model/AppliancesModel.dart';

class EditAppliancesPage extends StatefulWidget {
  const EditAppliancesPage({super.key});

  @override
  State<EditAppliancesPage> createState() => _EditAppliancesPageState();
}

class EditAppliancesService {
  static checkDatabaseValue(String docID, BuildContext context,
      String applianceName, String relay,String uid,String name) async {
    //print("hello");
    var snapshot = await FirebaseFirestore.instance
        .collection('appliances')
        .where("uid", isEqualTo: uid)
        .get()
        .then((value) {
      int count = 0;
      bool name = false;

      for (var document in value.docs) {
        print('${document.id} => ${document.data()}');
        if (document.data()['name'] == applianceName) {
          PredefinedWidgets.showMyErrorDialog(
              context,
              "This Appliance name is already taken up",
              "The  name $applianceName is already taken up by another device. Please choose another relay or delete this one");
          count++;
          break;
        } else if (document.data()['relay'] == relay) {
          if(name!=document.data()['name']){
             PredefinedWidgets.showMyErrorDialog(
              context,
              "This Relay is already taken up",
              "The $relay is already taken up by another device. Please choose another relay or delete this one");
          count++;
          break;
        }
          }
         
      }
      if (count == 0) {
        editApplicanceToDB(docID, context, applianceName, relay);
      }
    });
  }

  static Future<void> editApplicanceToDB(String docID, BuildContext context,
      String applianceName, String relay) async {
    //print("${Get.arguments} $applianceName $relay ");
    await FirebaseFirestore.instance.collection("Medicine").doc(docID).update({
      "name": applianceName,
      "relay": relay,
    }).then((value) {
      Get.back();
      PredefinedWidgets.showMySuccessDialog(
          context,
          "Appliance Successfully added",
          "The appliance $applianceName which is connected to $relay has been successfully added.");
    }).onError((error, stackTrace) {
      PredefinedWidgets.showMyErrorDialog(
          context, "Error", "Their has been an error when adding item");
    });
  }
}

class _EditAppliancesPageState extends State<EditAppliancesPage> {
  final nameController = TextEditingController();
  String dropDownvalue = 'Relay1';
  List<String> listOfRelay = <String>['Relay1', 'Relay2', 'Relay3', 'Relay4'];
  late AppliancesModel app = Get.arguments;
  @override
  void initState() {
    // TODO: implement initState
    dropDownvalue = app.relay;
    nameController.text = app.name;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Edit appliances"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                controller: nameController,
                //obscureText: obscuretext,
                decoration: InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                  ),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400)),
                  fillColor: Colors.grey.shade200,
                  filled: true,
                  hintText: "Appliance name",
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: DropdownButton<String>(
                  value: dropDownvalue,
                  items:
                      listOfRelay.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      dropDownvalue = newValue!;
                    });
                  }),
            ),
            const SizedBox(
              height: 10,
            ),
            PredefinedWidgets.myButton(context, () {
              if (nameController.text.isEmpty) {
                PredefinedWidgets.showMyErrorDialog(
                    context,
                    "Appliance name is Empty",
                    "The appliance must be named,It cannot be empty");
              } else if (dropDownvalue == "Choose an Relay") {
                PredefinedWidgets.showMyErrorDialog(
                    context,
                    "Incorrect Relay value",
                    "A Relay must be chosen,It cannot be the value 'Choose a Relay'");
              } else {
                EditAppliancesService.checkDatabaseValue(
                    app.docID, context, nameController.text, dropDownvalue,app.uID,app.name);
              }
              // AddApplianceService.addApplicanceToDB(
              //     nameController.text, dropDownvalue);
              //debugPrint("${nameController.text} $dropDownvalue");
            }, "Add appliance"),
          ],
        ),
      ),
    );
  }
}
