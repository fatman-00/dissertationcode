class EmergencyContactModel {
  String docID;
  String name;
  String msg;
  String contactNum;
  EmergencyContactModel(this.docID, this.name, this.msg, this.contactNum);
}