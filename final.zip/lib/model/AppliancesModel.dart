class AppliancesModel {
  String docID;
  String name;
  String relay;
  String uID;
  AppliancesModel(this.docID, this.name, this.relay,this.uID);
}