class RoutineModel {
  String docID;
  String name;
  int Relay1;
  int Relay2;
  int Relay3;
  int Relay4;
  String message;
  String time;
  String uID;
  RoutineModel(this.docID, this.name, this.Relay1, this.Relay2, this.Relay3,
      this.Relay4, this.message, this.time, this.uID);
}
