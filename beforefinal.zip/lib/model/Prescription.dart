class Prescription {
  String docID;
  String presName;
  String qrURL;
  String uID;
  String doctorID;
  String date;
  Prescription(this.docID, this.presName, this.qrURL, this.uID, this.doctorID,this.date);
}